package org.com.springcore.springjdbc.daotemplate;

import java.util.List;

public interface StudentDao {
	 public int insert(Students student) ;
	  public int getUpdate(Students student);
	  public int delete(int studentId);
	  public Students getStudent(int studentId);
	  public List<Students> getAllStudents();
}
