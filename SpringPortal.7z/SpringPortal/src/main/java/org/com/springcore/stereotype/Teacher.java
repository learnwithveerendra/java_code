package org.com.springcore.stereotype;

public class Teacher {
  private String name;
  private String departement;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDepartement() {
	return departement;
}
public void setDepartement(String departement) {
	this.departement = departement;
}
@Override
public String toString() {
	return "Teacher [name=" + name + ", departement=" + departement + "]";
}
}
