package org.com.springcore.collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/collections/collection.xml");
		  Emp employee1=(Emp)context.getBean("emp");
		  System.out.println(employee1);
		  System.out.println(employee1.getPhoneList().getClass());

	}

}
