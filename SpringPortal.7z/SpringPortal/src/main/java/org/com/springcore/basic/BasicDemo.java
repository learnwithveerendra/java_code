package org.com.springcore.basic;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BasicDemo {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/basic/spring_basic.xml");
		                   Student student1=(Student) context.getBean("student");
		                   System.out.println(student1);
		                   System.out.println("\n");
		                   Student student2=(Student) context.getBean("student_p");
		                   System.out.println("Using p schema ");
		                   System.out.println("\n");
		                   System.out.println(student2);
		                   
		                   Student student3=(Student) context.getBean("student3");
		                   System.out.println("\n");
		                   System.out.println("Using Attribute ");
		                   System.out.println("\n");
		                   System.out.println(student3);
		                   
		                   
		                   

	}

}
