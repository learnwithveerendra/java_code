package org.com.springcore.collections;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Emp {
  private int empId;
  private String empName;
  private List<String> phoneList;
  private Set<String> addressList;
  private Map<String, String> coursesList;
  
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public List<String> getPhoneList() {
	return phoneList;
}
public void setPhoneList(List<String> phoneList) {
	this.phoneList = phoneList;
}
public Set<String> getAddressList() {
	return addressList;
}
public void setAddressList(Set<String> addressList) {
	this.addressList = addressList;
}
public Map<String, String> getCoursesList() {
	return coursesList;
}
public void setCoursesList(Map<String, String> coursesList) {
	this.coursesList = coursesList;
}
/*
 * @Override public String toString() { return "Emp [empId=" + empId +
 * ", empName=" + empName + ", phoneList=" + phoneList + "]"; }
 */
/*
 * @Override public String toString() { return "Emp [empId=" + empId +
 * ", empName=" + empName + ", phoneList=" + phoneList + ", addressList=" +
 * addressList + "]"; }
 */
@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + ", phoneList=" + phoneList + ", addressList=" + addressList
			+ ", coursesList=" + coursesList + "]";
}
  
}
