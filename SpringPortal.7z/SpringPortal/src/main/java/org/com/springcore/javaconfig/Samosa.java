package org.com.springcore.javaconfig;

public class Samosa {
  public void display() {
	  System.out.println("My Price is little bit High..");
  }
}
