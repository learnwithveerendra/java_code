package org.com.springcore.springjdbc.daotemplate;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		System.out.println("Programe is started..");
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"org/com/springcore/springjdbc/daotemplate/springjdbc.xml");
		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
		/*
		 * Students student = new Students();
		 * 
		 * student.setStudentId(101); student.setStudentName("Jaya Srivastava");
		 * student.setCity("Gorakhpur"); int result=studentDao.insert(student);
		 * 
		 * 
		 * student.setStudentId(101); student.setStudentName("Raj Kumar");
		 * student.setCity("Lucknow"); int result = studentDao.getUpdate(student);
		 * System.out.println("Data Successfully update : " + result);
		 */

		// System.out.println("Number of Record is updated : "+result);

		// delete operation

		/*
		 * int result1 = studentDao.delete(101);
		 * System.out.println("Recorde is deleted " + result1);
		 */

		Students student = studentDao.getStudent(101);
		System.out.println(student);
		System.out.println("Fetch alll records..");

		List<Students> studentList = studentDao.getAllStudents();
		for (Students s : studentList) {
			System.out.println(s);
		}

	}

}
