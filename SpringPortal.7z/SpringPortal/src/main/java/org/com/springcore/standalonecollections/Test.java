package org.com.springcore.standalonecollections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
  public static void main(String[]args) {
	  
	  ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/standalonecollections/standalone.xml");
	     ///Person person2=(Person)context.getBean("person2");
	     
	     Person person=(Person)context.getBean("person");
	     System.out.println(person);
	    // System.out.println(person2);
	     System.out.println(person.getFeesstructure().getClass());
	   //  System.out.println(person2.getFriends().getClass());
	  
  }
}
