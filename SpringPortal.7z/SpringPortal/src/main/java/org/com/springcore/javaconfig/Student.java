package org.com.springcore.javaconfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {
	private Samosa samosa;
	@Value("Jaya Srivastava")
	private String studentName;
  public void getDisplay() {
	  samosa.display();
	  System.out.println("Hello Annotation...");
  }
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
@Override
public String toString() {
	return "Student [studentName=" + studentName + "]";
}
public Student(Samosa samosa) {
	super();
	this.samosa = samosa;
}
}
