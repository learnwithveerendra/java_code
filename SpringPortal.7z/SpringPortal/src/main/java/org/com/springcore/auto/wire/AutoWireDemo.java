package org.com.springcore.auto.wire;

//import org.com.ci;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWireDemo {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/auto/wire/autowire.xml");
        Employee employee1 = (Employee)context.getBean("emp");
        System.out.println(employee1);

	}

}
