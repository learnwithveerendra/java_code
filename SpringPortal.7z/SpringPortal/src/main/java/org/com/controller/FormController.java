package org.com.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import org.com.models.User;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FormController {
	@RequestMapping("/register")
	public String getRegisterForm() {
		return "register";
		
	}
	
	// from view to controller using httpservlet request
		@RequestMapping(path="/registerprocess",method = RequestMethod.POST)
		public String handleRegisterForm(HttpServletRequest request){
			System.out.println("within process method");
			String username=request.getParameter("username");
			System.out.println("User Name : "+username);
			String email=request.getParameter("email");
			System.out.println("Email : "+email);
			String password=request.getParameter("password");
			System.out.println("Password : "+password);
			return "register_success";
			
		}
		
		@RequestMapping("/register1")
		public String getRegisterForm1() {
			return "register1";
			
		}
		@RequestMapping(path="/registerprocess1",method = RequestMethod.POST)
		public String handleRegisterFormModel(Model m,@RequestParam("studentId") String userid ,@RequestParam("username")String username,@RequestParam("email")String email,@RequestParam("password")String password,@RequestParam("action") String actionName){
			
			
			System.out.println("User Name : "+username);
			
			m.addAttribute("userid", userid);
			m.addAttribute("username", username);
			//m.addAttribute("actionname", actionName);
			//System.out.println("actionName : "+actionName);
			m.addAttribute("email", email);
			m.addAttribute("password", password);
			System.out.println("Email : "+email);
			System.out.println("Password : "+password);
			return "register_success1";
			
		}
		
		// Using Model attribute...
		
		@RequestMapping("/modelattribute")
		public String getRegisterForm2() {
			return "model_and_attribute_contact";
			
		}
		
		
		
		
		@RequestMapping(path="/registerprocess2",method = RequestMethod.POST)
		public String handleRegisterFormModel2(Model model,@RequestParam("userName")String userName,@RequestParam("email")String email,@RequestParam("password")String password){
			
			User user=new User();
			user.setEmail(email);
			user.setUserName(userName);
			user.setPassword(password);
			model.addAttribute("user", user);
			//System.out.println("User Name : "+username);
			
			//m.addAttribute("userid", userid);
			//m.addAttribute("username", username);
			//m.addAttribute("actionname", actionName);
			//System.out.println("actionName : "+actionName);
			////m.addAttribute("email", email);
			//m.addAttribute("password", password);
			System.out.println("User Name : "+userName);
			System.out.println("Email : "+email);
			System.out.println("Password : "+password);
			return "register_success2";
			
		}
	// Using Model attribute...
		
		@RequestMapping("/modelattribute1")
		public String getRegisterForm3() {
			return "model_and_attribute_contact_1";
			
		}
		
		//  model_and_attribute_contact_1
		@RequestMapping(path="/modelattributeregisterprocess",method = RequestMethod.POST)
		public String handleRegisterFormModel3(@ModelAttribute User user, Model model){
			System.out.println(user);
			
			model.addAttribute("user", user);
		
		
			return "model_attribute_success";
			
		}
}
