package org.com.springcore.stereotype;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StereoTypeDemo {

	public static void main(String[] args) {
		 ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/stereotype/stereotype.xml");	
         
		      Student student1 = (Student)context.getBean("obj");
		      System.out.println(student1.hashCode());
		      Student student2 = (Student) context.getBean("obj");
              System.out.println(student2.hashCode());
              System.out.println(student1);
              Teacher teacher1=(Teacher)context.getBean("teacher");
              Teacher teacher2=(Teacher)context.getBean("teacher");
                 System.out.println(teacher1.hashCode());
                 System.out.println(teacher2.hashCode());
	}

}
