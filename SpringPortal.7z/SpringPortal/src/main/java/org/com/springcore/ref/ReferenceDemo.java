package org.com.springcore.ref;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ReferenceDemo {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/ref/ref.xml");
		     A aobj = (A)context.getBean("a");
		     System.out.println(aobj);

	}

}
