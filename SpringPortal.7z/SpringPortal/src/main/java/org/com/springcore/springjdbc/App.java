package org.com.springcore.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App {

	public static void main(String[] args) {
		System.out.println("Programe is started..");
		ApplicationContext context=new ClassPathXmlApplicationContext("org/com/springcore/springjdbc/springjdbc.xml");
		JdbcTemplate jdbcTemplate= context.getBean("jdbcTemplate",JdbcTemplate.class);
		String query= "insert into Student(id,name,city) values (?,?,?)";
		int result=jdbcTemplate.update(query,101,"Zuber Kumar","Delhi");
		System.out.println("Database Inserted successfully");
		       

	}

}
