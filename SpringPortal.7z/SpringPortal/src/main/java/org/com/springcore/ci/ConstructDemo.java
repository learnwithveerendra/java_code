package org.com.springcore.ci;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConstructDemo {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/ci/constructor.xml");
                           Person person = (Person)context.getBean("person");
                           System.out.println(person);
	}

}
  //  org.com.springcore.basic