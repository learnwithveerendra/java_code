package org.com.springcore.auto.wire.annotation;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWireDemo {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context= new ClassPathXmlApplicationContext("/org/com/springcore/auto/wire/annotation/autowire.xml");
        Employee employee1 = (Employee)context.getBean("emp1");
        System.out.println(employee1);

	}

}
