package org.com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {
	
	// basic first demo of spring mvc..
  @RequestMapping("/welcome")
  public String getWelcome() {
	  return "welcome";
  }
  @RequestMapping("/about")
  public String getAbout() {
	  return "about";
  }
  
  // Data transfer from controller to views
  @RequestMapping("/model")
  public String getAbout(Model m) {
	  System.out.println("This is model method ");
	  m.addAttribute("name","Veerendra Srivastava");
	  List<String> friendList=new ArrayList<String>();
	               friendList.add("Jaya");
	               friendList.add("Angel");
	               friendList.add("Prince");
	 m.addAttribute("friendList", friendList);              
	               
	  return "model";
  }
  
  
  
//Data transfer from controller to views through model and view
 @RequestMapping("/modelandview")
 public ModelAndView getModelAndView() {
	  System.out.println("This is model and view method ");
	  ModelAndView mv=new ModelAndView();
	  mv.addObject("name","Model and View name ");
		
	  mv.setViewName("modelandview");
	               
	  return mv;
 }
//Data transfer from controller to views through model and view using jstl
 @RequestMapping("/modelandviewjstl")
 public ModelAndView getModelAndView_JSTL() {
	  System.out.println("This is model and view jstl method ");
	  ModelAndView mv=new ModelAndView();
	  mv.addObject("name","Model and View name ");
		
	  mv.setViewName("jstl");
List<Integer> list=new ArrayList<>();
     list.add(12);
     list.add(3456);
     list.add(7890);
     mv.addObject("marks",list);
     
	  return mv;
 }
  
}
