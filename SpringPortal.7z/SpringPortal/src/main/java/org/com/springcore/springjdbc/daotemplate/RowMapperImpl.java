package org.com.springcore.springjdbc.daotemplate;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RowMapperImpl implements RowMapper<Students> {

	public Students mapRow(ResultSet rs, int rowNum) throws SQLException {
		Students student=new Students();
		student.setStudentId(rs.getInt(1));
		student.setStudentName(rs.getString(2));
		student.setCity(rs.getString(3));
		
		return student;
	}

}
