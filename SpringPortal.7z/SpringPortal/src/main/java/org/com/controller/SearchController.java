package org.com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SearchController {
	
	@RequestMapping("/user/{userId}")
	public String getUserDetails1(@PathVariable("userId") int userId) {
		System.out.println(userId);
		
		System.out.println(userId);
		return "home";
	}
	@RequestMapping("/user/{userId}/{userName}")
	public String getUserDetails(@PathVariable("userId") int userId,@PathVariable("userName") String userName) {
		System.out.println(userId);
		
		System.out.println(userName);
		return "home";
	}

}
